package g10nov2025;

//Author: motaniy Date: 24 Aug 2025
import javax.swing.JOptionPane;

//2.1 [2]
//1 mark name of class
public class Awards
{

    //2.2 [3]
    //1 mark static
    //1 mark correct names
    //1 mark correct types
    static String pName;
    static int age;
    static int minPoints;
    static double averagePoints;
    static String goldList = "";
    static int goldCount;

    //1 mark main method
    public static void main(String[] args)
    {
        //6.1 [1]
        String school = JOptionPane.showInputDialog("Enter the name of your school");
        //6.2 [1]
        System.out.println("Award list for " + school + "\n");
        //6.3 [1]
        int numParticipants = Integer.parseInt(JOptionPane.showInputDialog("Enter the number of participants"));
        //6.4 [3]
        //1 mark starting from 1
        //1 mark <= numParticipants
        //1 mark for loop
        for (int i = 1; i <= numParticipants; i++)
        {
            //6.4.1 [2]
            //1 mark for print
            //1 mark for i
            System.out.print("Participant " + i + ": ");
            //6.4.2 [3]
            getParticipantDetails();
            enterPoints();
            displayAward();
        }
        //6.5 [1]
        System.out.println("Gold achieved by " + goldCount + " participant(s):");
        //6.6 [1]
        System.out.println(goldList);
    }

    //3.1 [1]
    static void getParticipantDetails()
    {
        //3.2 [2]
        pName = JOptionPane.showInputDialog("Enter participant name").toUpperCase();
        //3.3 [1]
        age = Integer.parseInt(JOptionPane.showInputDialog(
                "Enter participant age"));
        //3.3.1 [4]
        //1 mark while
        //1 mark conditions
        //1 mark for or
        //1 mark for appropriate error in change
        while (age < 15 || age > 19)
        {
            age = Integer.parseInt(JOptionPane.showInputDialog("Invalid age (must be between 15-19)"));
        }
        //3.4 [5]
        //1 mark for concatenation
        //1 mark for charAt(0)
        //1 mark for (int)(Math.random()
        //1 mark for * 90
        //1 mark for + 10 with correct brackets
        String participantCode = "P-" + age + pName.charAt(0) + (int) (Math.random() * 90 + 10);
        //3.5 [2]
        //1 mark for sout
        //1 mark for correct concat
        System.out.println(participantCode + "\n\tName: " + pName + "\tAge: " + age);
    }

    //4.1 [1]
    static void enterPoints()
    {
        //4.2 [3]
        //1 mark type
        //1 mark names
        //1 mark initial values
        int points;
        int totalPoints = 0;
        String category = "Fitness";
        String minCategory;
        //4.3.1 [2]
        points = Integer.parseInt(JOptionPane.showInputDialog("Enter the points for " + category));
        //4.3.2 [1]
        System.out.println("\t\t" + category + ": " + points);
        //4.3.3 [2]
        totalPoints += points;
        //4.4 [1]
        minPoints = points;
        minCategory = category;
        //4.5 [1]
        for (int i = 1; i < 4; i++)
        {
            //4.5.1 [5]
            //1 mark for switch 
            //1 mark for using i
            //1 mark for correct cases
            //1 mark for correct category assignment
            //1 mark for all three
            switch (i)
            {
                case 1:
                    category = "Skills";
                    break;
                case 2:
                    category = "Service";
                    break;
                case 3:
                    category = "Camp";
                    break;
            }
            //4.5.2 [1] for copying all three
            points = Integer.parseInt(JOptionPane.showInputDialog("Enter the points for " + category));
            System.out.println("\t\t" + category + ": " + points);
            totalPoints += points;
            //4.5.3 [4]
            //1 mark for if
            //1 mark for condition
            //1 mark for assigning minPoints
            //1 mark for assinging minCategory
            if (points < minPoints)
            {
                minPoints = points;
                minCategory = category;
            }
        }
        //4.6 [4]
        //1 mark for Math.round
        //1 mark for totalPoints/4.0
        //1 mark for * 10 in brackets
        //1 mark for / 10.0
        averagePoints = Math.round(totalPoints / 4.0 * 10) / 10.0;
        //4.7 [1]
        System.out.println("\tAverage points: " + averagePoints + " with a minimum of " + minPoints + " in " + minCategory);
    }

    //5.1 [1]
    static void displayAward()
    {
        //5.2.1 [7]
        //1 mark for using nested if
        //1 mark for correct age on all three
        //1 mark for correct minPoints on all three
        //1 mark for correct averagePoints on all three
        //1 mark for using and
        //1 mark for correct messages
        //1 mark for correct else
        if (age >= 17 && minPoints >= 30 && averagePoints >= 60)
        {
            System.out.println("Award: Gold\n");
            //5.3.1 [2]
            goldList += pName + "\n";
            //5.3.2 [1]
            goldCount++;
        } //5.2.2 [1]
        else if (age >= 16 && minPoints >= 25 && averagePoints >= 50)
        {
            System.out.println("Award: Silver\n");
        } //5.2.3 [1]
        else if (age >= 15 && minPoints >= 20 && averagePoints >= 40)
        {
            System.out.println("Award: Bronze\n");
        } //5.2.4 [1]
        else
        {
            System.out.println("Award Not Achieved\n");
        }
    }
}
