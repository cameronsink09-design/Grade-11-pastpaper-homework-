#
# DUMP FILE
#
# Database is ported from MS Access
#------------------------------------------------------------------
# Created using "MS Access to MySQL" form http://www.bullzip.com
# Program Version 5.5.282
#
# OPTIONS:
#   sourcefilename=C:/Users/DeliaKench/OneDrive - Funworks/Downloads/G10Nov2025Mod (1)/Learner Files/PresidentsAward.mdb
#   sourceusername=
#   sourcepassword=
#   sourcesystemdatabase=
#   destinationdatabase=PresidentsAward
#   storageengine=InnoDB
#   dropdatabase=0
#   createtables=1
#   unicode=1
#   autocommit=1
#   transferdefaultvalues=1
#   transferindexes=1
#   transferautonumbers=1
#   transferrecords=1
#   columnlist=1
#   tableprefix=
#   negativeboolean=0
#   ignorelargeblobs=0
#   memotype=LONGTEXT
#   datetimetype=DATETIME
#

CREATE DATABASE IF NOT EXISTS `PresidentsAward`;
USE `PresidentsAward`;

#
# Table structure for table 'tblParticipants'
#

DROP TABLE IF EXISTS `tblParticipants`;

CREATE TABLE `tblParticipants` (
  `ID` INTEGER NOT NULL AUTO_INCREMENT, 
  `pName` VARCHAR(255), 
  `school` VARCHAR(255), 
  `birthDate` DATE, 
  `age` INTEGER, 
  `avePoints` DOUBLE NULL, 
  `minPoints` INTEGER, 
  `campDone` TINYINT(1), 
  PRIMARY KEY (`ID`)
) ENGINE=innodb DEFAULT CHARSET=utf8;

SET autocommit=1;

#
# Dumping data for table 'tblParticipants'
#

INSERT INTO `tblParticipants` (`ID`, `pName`, `school`, `birthDate`, `age`, `avePoints`, `minPoints`, `campDone`) VALUES (1, 'Zuri Bangura', 'St David''s', '2009-11-15', 15, 32.5, 21, 1);
INSERT INTO `tblParticipants` (`ID`, `pName`, `school`, `birthDate`, `age`, `avePoints`, `minPoints`, `campDone`) VALUES (2, 'Andile Mokoena', 'Crawford', '2010-05-31', 15, 28, 17, 1);
INSERT INTO `tblParticipants` (`ID`, `pName`, `school`, `birthDate`, `age`, `avePoints`, `minPoints`, `campDone`) VALUES (3, 'Ayanda Mahlangu', 'Crawford', '2007-05-08', 18, 19, 13, 0);
INSERT INTO `tblParticipants` (`ID`, `pName`, `school`, `birthDate`, `age`, `avePoints`, `minPoints`, `campDone`) VALUES (4, 'Gugu Pillay', 'Crawford', '2010-06-27', 15, 49.75, 44, 0);
INSERT INTO `tblParticipants` (`ID`, `pName`, `school`, `birthDate`, `age`, `avePoints`, `minPoints`, `campDone`) VALUES (5, 'Refilwe Dlamini', 'De La Salle', '2009-08-17', 16, 45.75, 39, 0);
INSERT INTO `tblParticipants` (`ID`, `pName`, `school`, `birthDate`, `age`, `avePoints`, `minPoints`, `campDone`) VALUES (6, 'Tarun Vempati', 'St David''s', '2009-06-07', 16, 21.75, 17, 1);
INSERT INTO `tblParticipants` (`ID`, `pName`, `school`, `birthDate`, `age`, `avePoints`, `minPoints`, `campDone`) VALUES (7, 'Rebecca Mills', 'Kingsmead', '2008-02-07', 17, 50.25, 39, 0);
INSERT INTO `tblParticipants` (`ID`, `pName`, `school`, `birthDate`, `age`, `avePoints`, `minPoints`, `campDone`) VALUES (8, 'Kaedyn Pillay', 'Crawford', '2007-09-19', 17, 53.75, 39, 1);
INSERT INTO `tblParticipants` (`ID`, `pName`, `school`, `birthDate`, `age`, `avePoints`, `minPoints`, `campDone`) VALUES (9, 'Kiren Naidoo', 'De La Salle', '2008-10-15', 16, 33.75, 20, 1);
INSERT INTO `tblParticipants` (`ID`, `pName`, `school`, `birthDate`, `age`, `avePoints`, `minPoints`, `campDone`) VALUES (10, 'Thandi Dlamini', 'Private', '2006-11-30', 18, 64.75, 42, 0);
INSERT INTO `tblParticipants` (`ID`, `pName`, `school`, `birthDate`, `age`, `avePoints`, `minPoints`, `campDone`) VALUES (11, 'Naledi Pillay', 'Private', '2009-01-20', 16, 65.25, 40, 1);
INSERT INTO `tblParticipants` (`ID`, `pName`, `school`, `birthDate`, `age`, `avePoints`, `minPoints`, `campDone`) VALUES (12, 'Sizwe Mahlangu', 'De La Salle', '2008-10-11', 16, 26.25, 20, 1);
INSERT INTO `tblParticipants` (`ID`, `pName`, `school`, `birthDate`, `age`, `avePoints`, `minPoints`, `campDone`) VALUES (13, 'Ayanda Van Wyk', 'Private', '2006-12-03', 18, 26.75, 20, 0);
INSERT INTO `tblParticipants` (`ID`, `pName`, `school`, `birthDate`, `age`, `avePoints`, `minPoints`, `campDone`) VALUES (14, 'Nomsa Mahlangu', 'De La Salle', '2009-04-01', 16, 37, 24, 0);
INSERT INTO `tblParticipants` (`ID`, `pName`, `school`, `birthDate`, `age`, `avePoints`, `minPoints`, `campDone`) VALUES (15, 'Ameera Tayob', 'Kingsmead', '2009-07-28', 16, 47.5, 24, 1);
INSERT INTO `tblParticipants` (`ID`, `pName`, `school`, `birthDate`, `age`, `avePoints`, `minPoints`, `campDone`) VALUES (16, 'Aaliya Khan', 'Kingsmead', '2006-08-29', 18, 60.75, 46, 1);
INSERT INTO `tblParticipants` (`ID`, `pName`, `school`, `birthDate`, `age`, `avePoints`, `minPoints`, `campDone`) VALUES (17, 'Ayanda Zedwala', 'St David''s', '2009-02-01', 16, 32.75, 22, 0);
INSERT INTO `tblParticipants` (`ID`, `pName`, `school`, `birthDate`, `age`, `avePoints`, `minPoints`, `campDone`) VALUES (18, 'Ella Ambrien', 'Kingsmead', '2008-03-16', 17, 34.25, 29, 0);
INSERT INTO `tblParticipants` (`ID`, `pName`, `school`, `birthDate`, `age`, `avePoints`, `minPoints`, `campDone`) VALUES (19, 'Ayanda Khumalo', 'Private', '2010-04-08', 15, 35, 26, 1);
INSERT INTO `tblParticipants` (`ID`, `pName`, `school`, `birthDate`, `age`, `avePoints`, `minPoints`, `campDone`) VALUES (20, 'Zanele Nkosi', 'Kingsmead', '2009-08-17', 16, 66.75, 59, 0);
INSERT INTO `tblParticipants` (`ID`, `pName`, `school`, `birthDate`, `age`, `avePoints`, `minPoints`, `campDone`) VALUES (21, 'Zanele Mahlangu', 'Private', '2009-03-25', 16, 56.75, 49, 0);
INSERT INTO `tblParticipants` (`ID`, `pName`, `school`, `birthDate`, `age`, `avePoints`, `minPoints`, `campDone`) VALUES (22, 'Dylan Botha', 'St David''s', '2007-02-18', 18, 41.75, 31, 1);
INSERT INTO `tblParticipants` (`ID`, `pName`, `school`, `birthDate`, `age`, `avePoints`, `minPoints`, `campDone`) VALUES (23, 'Gugu Dlamini', 'Crawford', '2007-08-26', 17, 63.5, 57, 0);
INSERT INTO `tblParticipants` (`ID`, `pName`, `school`, `birthDate`, `age`, `avePoints`, `minPoints`, `campDone`) VALUES (24, 'Kgethego Munyai', 'St David''s', '2007-08-08', 18, 64, 45, 1);
INSERT INTO `tblParticipants` (`ID`, `pName`, `school`, `birthDate`, `age`, `avePoints`, `minPoints`, `campDone`) VALUES (25, 'Miles Pegg', 'St David''s', '2008-09-25', 16, 66.25, 58, 0);
INSERT INTO `tblParticipants` (`ID`, `pName`, `school`, `birthDate`, `age`, `avePoints`, `minPoints`, `campDone`) VALUES (26, 'Elri Van Wyk', 'St Mary''s', '2007-09-02', 17, 46.25, 39, 0);
INSERT INTO `tblParticipants` (`ID`, `pName`, `school`, `birthDate`, `age`, `avePoints`, `minPoints`, `campDone`) VALUES (27, 'Lethabo Nkosi', 'Roedean', '2007-10-12', 17, 26.25, 11, 1);
INSERT INTO `tblParticipants` (`ID`, `pName`, `school`, `birthDate`, `age`, `avePoints`, `minPoints`, `campDone`) VALUES (28, 'Sipho Nkosi', 'St John''s', '2009-12-10', 15, 46.25, 27, 1);
INSERT INTO `tblParticipants` (`ID`, `pName`, `school`, `birthDate`, `age`, `avePoints`, `minPoints`, `campDone`) VALUES (29, 'Refilwe Mthembu', 'St Stithians', '2009-03-23', 16, 46.25, 35, 1);
INSERT INTO `tblParticipants` (`ID`, `pName`, `school`, `birthDate`, `age`, `avePoints`, `minPoints`, `campDone`) VALUES (30, 'Roger Owen', 'Hilton', '2007-12-10', 17, 46.25, 21, 1);
# 30 records

