/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pkg2024.section.b;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Locale;
import java.util.Scanner;

/**
 *
 * @author Charlene
 */
public class RentalArray
{

    private Rental[] rArr = new Rental[50];
    private int size;

    public RentalArray()
    {
        try
        {
            Scanner scFile = new Scanner(new File("rentalData.txt"));

            while (scFile.hasNext())
            {

                String line = scFile.nextLine();
                Scanner scLine = new Scanner(line).useDelimiter(",");

                String name = scLine.next();
                String reg = scLine.next();
                String type = scLine.next();
                double cost = Double.parseDouble(scLine.next());
                String timeTaken = scLine.next();
                String timeReturned = scLine.next();

                DateTimeFormatter f = DateTimeFormatter.ofPattern("dd/MM/yyyy");
                LocalDate t = LocalDate.parse(timeTaken, f);
                LocalDate r = LocalDate.parse(timeReturned, f);

                rArr[size] = new Rental(name, reg, type, cost, t, r);
                size++;

            }
            scFile.close();

        } catch (FileNotFoundException e)
        {
            System.out.println("The file has not been found!");
        }
    }

    public String toString()
    {
        String temp = "";
        for (int i = 0; i < size; i++)
        {
            temp += rArr[i].toString() + "\n";
        }

        return temp;
    }

    public void sort()
    {
        Rental temp = null;
        for (int i = 0; i < size - 1; i++)
        {
            for (int j = i + 1; j < size; j++)
            {
                if (rArr[i].getReturned().isBefore(rArr[j].getReturned()))
                {
                    temp = rArr[i];
                    rArr[i] = rArr[j];
                    rArr[j] = temp;
                }
            }
        }
    }

     public String getVechicleByType(String type)
    {
        String temp = "Type: " + type + "\n";
        for (int i = 0; i < size; i++)
        {
            if (rArr[i].getType().equals(type))
            {
                temp += rArr[i].getRegNo()
                        + "\t" + rArr[i].getType()
                        + "\n";
            }
        }
        return temp;
    }

    public String monthlyTotals()
    {
        String temp = "Summary report generated on: " + LocalDate.now() 
                + "\n****************************\n";

        temp += "\nNumber of Rentals: " + Rental.totalRentals + "\n";
     
        double yearlyIncome = 0;

        for (int m = 1; m < 13; m++)
        {
            double total = 0;
            for (int i = 0; i < size; i++)
            {
                if (rArr[i].getTaken().getMonthValue() == m)
                {
                    total += rArr[i].getRentalCost();
                }
            }
            temp += "Total for month " + m + ": R" + total + "\n";
            yearlyIncome += total;
        }

        temp += "\nTotal Income year to date: R " + yearlyIncome;
        return temp;        
    }
}
