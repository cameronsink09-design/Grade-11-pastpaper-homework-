/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pkg2024.section.b;

import java.time.LocalDateTime;

/**
 *
 * @author Charlene
 */
public class RentalUI {
    public static void main(String[] args) {
        RentalArray ra = new RentalArray();
       
        ra.sort();
        System.out.println(ra); 
                    
        System.out.println(ra.getVechicleByType("Sedan"));
               
        System.out.println(ra.monthlyTotals());
        
        
    }
}
