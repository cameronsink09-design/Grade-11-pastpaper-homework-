/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pkg2024.section.b;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;

/**
 *
 * @author Charlene
 */
public class Rental
{

    private String cName;
    private String regNo;
    private String type;
    private double cost;

    private LocalDate taken;
    private LocalDate returned;

    private static final double BASE_FEE = 1000;

    public static int totalRentals;

    public Rental(String inCn, String inR, String inT, double inC, LocalDate inTkn, LocalDate inRet)
    {
        cName = inCn;
        regNo = inR;
        type = inT;
        cost = inC;
        taken = inTkn;
        returned = inRet;

        totalRentals++;
    }

    public String getRegNo()
    {
        return regNo;
    }

    public String getType()
    {
        return type;
    }

    public LocalDate getTaken()
    {
        return taken;
    }

    public LocalDate getReturned()
    {
        return returned;
    }

    private int numDaysRented()
    {
        long days = ChronoUnit.DAYS.between(taken, returned);
        return (int) days;
    }

    public double getRentalCost()
    {
        return numDaysRented() * cost + BASE_FEE;
    }

    public String toString()
    {
        DateTimeFormatter f = DateTimeFormatter.ofPattern("dd MMM yyyyy");

        String temp = "";

        temp = cName + "\n************\n" + regNo + "\t@ R" + cost + " per hour";
        temp += "\nDate Rented: " + f.format(taken) + "\nDate Returned: "
                + f.format(returned) + "\n";
        temp += "Total Days : " + numDaysRented() + "\n";
        temp += "R " + getRentalCost() + "\n";

        return temp;
    }

}
