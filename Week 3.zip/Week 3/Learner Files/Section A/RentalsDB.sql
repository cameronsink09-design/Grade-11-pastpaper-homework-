#
# DUMP FILE
#
# Database is ported from MS Access
#------------------------------------------------------------------
# Created using "MS Access to MySQL" form http://www.bullzip.com
# Program Version 5.5.282
#
# OPTIONS:
#   sourcefilename=G:/Shared drives/IT TeacherWorks/Assessments/2024/G11 Nov Exams 2024/G11 Nov Prac 2024/Learner Files/Section A/RentalsDB.mdb
#   sourceusername=
#   sourcepassword=
#   sourcesystemdatabase=
#   destinationdatabase=RentalsDB
#   storageengine=InnoDB
#   dropdatabase=0
#   createtables=1
#   unicode=1
#   autocommit=1
#   transferdefaultvalues=1
#   transferindexes=1
#   transferautonumbers=1
#   transferrecords=1
#   columnlist=1
#   tableprefix=
#   negativeboolean=0
#   ignorelargeblobs=0
#   memotype=LONGTEXT
#   datetimetype=DATETIME
#

CREATE DATABASE IF NOT EXISTS `RentalsDB`;
USE `RentalsDB`;

#
# Table structure for table 'tblRentals'
#

DROP TABLE IF EXISTS `tblRentals`;

CREATE TABLE `tblRentals` (
  `clientFirstName` VARCHAR(255), 
  `clientSurname` VARCHAR(255), 
  `regNo` VARCHAR(255), 
  `vehicleType` VARCHAR(255), 
  `dailyRate` INTEGER, 
  `fuelType` VARCHAR(255), 
  `Taken` DATE, 
  `Returned` DATE
) ENGINE=innodb DEFAULT CHARSET=utf8;

SET autocommit=1;

#
# Dumping data for table 'tblRentals'
#

INSERT INTO `tblRentals` (`clientFirstName`, `clientSurname`, `regNo`, `vehicleType`, `dailyRate`, `fuelType`, `Taken`, `Returned`) VALUES ('John', ' Doe', 'RHL 1444 WC', 'Sedan', 600, 'Hybrid', '2024-01-10', '2024-01-14');
INSERT INTO `tblRentals` (`clientFirstName`, `clientSurname`, `regNo`, `vehicleType`, `dailyRate`, `fuelType`, `Taken`, `Returned`) VALUES ('Peter', ' Nkosi', 'PKL 7811 ZN', 'Convertible', 2000, 'Hybrid', '2024-01-10', '2024-01-11');
INSERT INTO `tblRentals` (`clientFirstName`, `clientSurname`, `regNo`, `vehicleType`, `dailyRate`, `fuelType`, `Taken`, `Returned`) VALUES ('Kwazi', ' Khumalo', 'WTQ 9924 MP', 'Minivan', 850, 'Electric', '2024-01-10', '2024-01-17');
INSERT INTO `tblRentals` (`clientFirstName`, `clientSurname`, `regNo`, `vehicleType`, `dailyRate`, `fuelType`, `Taken`, `Returned`) VALUES ('John', ' Doe', 'RHL 1444 WC', 'Sedan', 600, 'Hybrid', '2024-01-12', '2024-01-18');
INSERT INTO `tblRentals` (`clientFirstName`, `clientSurname`, `regNo`, `vehicleType`, `dailyRate`, `fuelType`, `Taken`, `Returned`) VALUES ('Nomvula', ' Khumalo', 'XDT 5924 ZN', 'Sedan', 400, 'Electric', '2024-01-18', '2024-01-24');
INSERT INTO `tblRentals` (`clientFirstName`, `clientSurname`, `regNo`, `vehicleType`, `dailyRate`, `fuelType`, `Taken`, `Returned`) VALUES ('Mandla', ' Ncube', 'PER 2234 GP', NULL, 1200, 'Petrol', '2024-01-25', '2024-01-26');
INSERT INTO `tblRentals` (`clientFirstName`, `clientSurname`, `regNo`, `vehicleType`, `dailyRate`, `fuelType`, `Taken`, `Returned`) VALUES ('Sibongile', ' Mkhize', 'XQW 4697 MP', 'Minivan', 850, 'Petrol', '2024-01-29', '2024-02-01');
INSERT INTO `tblRentals` (`clientFirstName`, `clientSurname`, `regNo`, `vehicleType`, `dailyRate`, `fuelType`, `Taken`, `Returned`) VALUES ('Thandeka', ' Zulu', 'YPB 9493 NC', 'SUV', 1000, 'Petrol', '2024-02-03', '2024-02-07');
INSERT INTO `tblRentals` (`clientFirstName`, `clientSurname`, `regNo`, `vehicleType`, `dailyRate`, `fuelType`, `Taken`, `Returned`) VALUES ('Sam', ' Dube', 'LGP 3342 NC', 'SUV', 1100, 'Petrol', '2024-02-06', '2024-02-09');
INSERT INTO `tblRentals` (`clientFirstName`, `clientSurname`, `regNo`, `vehicleType`, `dailyRate`, `fuelType`, `Taken`, `Returned`) VALUES ('Ayanda', ' Gama', 'FLR 8813 GP', 'Convertible', 2000, 'Petrol', '2024-02-09', '2024-02-14');
INSERT INTO `tblRentals` (`clientFirstName`, `clientSurname`, `regNo`, `vehicleType`, `dailyRate`, `fuelType`, `Taken`, `Returned`) VALUES ('Ntombi', ' Nkosi', 'FSQ 9918 MP', 'Sedan', 650, 'Electric', '2024-02-11', '2024-02-12');
INSERT INTO `tblRentals` (`clientFirstName`, `clientSurname`, `regNo`, `vehicleType`, `dailyRate`, `fuelType`, `Taken`, `Returned`) VALUES ('Amahle', ' Tshabalala', 'SWQ 7818 GP', 'Minivan', 800, 'Petrol', '2024-02-15', '2024-02-19');
INSERT INTO `tblRentals` (`clientFirstName`, `clientSurname`, `regNo`, `vehicleType`, `dailyRate`, `fuelType`, `Taken`, `Returned`) VALUES ('Daniel', ' Smith', 'MRU 6619 FS', 'Sedan', 700, 'Electric', '2024-03-02', '2024-03-09');
INSERT INTO `tblRentals` (`clientFirstName`, `clientSurname`, `regNo`, `vehicleType`, `dailyRate`, `fuelType`, `Taken`, `Returned`) VALUES ('John', ' Doe', 'RHL 1444 WC', 'Sedan', 600, 'Hybrid', '2024-03-03', '2024-03-07');
INSERT INTO `tblRentals` (`clientFirstName`, `clientSurname`, `regNo`, `vehicleType`, `dailyRate`, `fuelType`, `Taken`, `Returned`) VALUES ('Thabo', ' Vilakazi', 'QWE 7719 NC', 'SUV', 900, 'Petrol', '2024-03-06', '2024-03-07');
INSERT INTO `tblRentals` (`clientFirstName`, `clientSurname`, `regNo`, `vehicleType`, `dailyRate`, `fuelType`, `Taken`, `Returned`) VALUES ('Mandla', ' Khumalo', 'YHJ 8824 MP', 'Sedan', 500, 'Electric', '2024-03-07', '2024-03-09');
INSERT INTO `tblRentals` (`clientFirstName`, `clientSurname`, `regNo`, `vehicleType`, `dailyRate`, `fuelType`, `Taken`, `Returned`) VALUES ('Emily', ' Brown', 'EAQ 0247 GP', 'SUV', 1200, 'Electric', '2024-03-08', '2024-03-12');
INSERT INTO `tblRentals` (`clientFirstName`, `clientSurname`, `regNo`, `vehicleType`, `dailyRate`, `fuelType`, `Taken`, `Returned`) VALUES ('Petros', ' Zwane', 'BGT 1124 ZN', NULL, 400, 'Electric', '2024-03-09', '2024-03-13');
INSERT INTO `tblRentals` (`clientFirstName`, `clientSurname`, `regNo`, `vehicleType`, `dailyRate`, `fuelType`, `Taken`, `Returned`) VALUES ('Busi', ' Nkosi', 'QLE 8834 ZN', 'Sedan', 400, 'Petrol', '2024-03-11', '2024-03-18');
INSERT INTO `tblRentals` (`clientFirstName`, `clientSurname`, `regNo`, `vehicleType`, `dailyRate`, `fuelType`, `Taken`, `Returned`) VALUES ('Lindiwe', ' Dlamini', 'GAC 0793 NC', NULL, 450, 'Petrol', '2024-03-12', '2024-03-14');
INSERT INTO `tblRentals` (`clientFirstName`, `clientSurname`, `regNo`, `vehicleType`, `dailyRate`, `fuelType`, `Taken`, `Returned`) VALUES ('Musa', ' Zungu', 'PSM 6724 FS', 'Minivan', 850, 'Electric', '2024-03-19', '2024-03-23');
INSERT INTO `tblRentals` (`clientFirstName`, `clientSurname`, `regNo`, `vehicleType`, `dailyRate`, `fuelType`, `Taken`, `Returned`) VALUES ('Ntombi', ' Nkosi', 'FSQ 9918 MP', 'Sedan', 650, 'Electric', '2024-03-23', '2024-03-24');
INSERT INTO `tblRentals` (`clientFirstName`, `clientSurname`, `regNo`, `vehicleType`, `dailyRate`, `fuelType`, `Taken`, `Returned`) VALUES ('Lebo', ' Mokoena', 'ZTQ 9871 GP', 'Convertible', 1500, 'Electric', '2024-03-30', '2024-04-02');
INSERT INTO `tblRentals` (`clientFirstName`, `clientSurname`, `regNo`, `vehicleType`, `dailyRate`, `fuelType`, `Taken`, `Returned`) VALUES ('Daniel', ' Smith', 'MRU 6619 FS', 'Sedan', 700, 'Electric', '2024-04-05', '2024-04-08');
INSERT INTO `tblRentals` (`clientFirstName`, `clientSurname`, `regNo`, `vehicleType`, `dailyRate`, `fuelType`, `Taken`, `Returned`) VALUES ('Nomvula', ' Khumalo', 'XDT 5924 ZN', 'Sedan', 400, 'Electric', '2024-04-16', '2024-04-17');
INSERT INTO `tblRentals` (`clientFirstName`, `clientSurname`, `regNo`, `vehicleType`, `dailyRate`, `fuelType`, `Taken`, `Returned`) VALUES ('Lebo', ' Mokoena', 'ZTQ 9871 GP', 'Convertible', 1500, 'Electric', '2024-04-18', '2024-04-21');
INSERT INTO `tblRentals` (`clientFirstName`, `clientSurname`, `regNo`, `vehicleType`, `dailyRate`, `fuelType`, `Taken`, `Returned`) VALUES ('Sibongile', ' Mkhize', 'XQW 4697 MP', 'Minivan', 850, 'Petrol', '2024-04-23', '2024-04-28');
INSERT INTO `tblRentals` (`clientFirstName`, `clientSurname`, `regNo`, `vehicleType`, `dailyRate`, `fuelType`, `Taken`, `Returned`) VALUES ('Phumzile', ' Shabalala', 'FWQ 9903 GP', 'Sedan', 400, 'Petrol', '2024-04-24', '2024-04-29');
INSERT INTO `tblRentals` (`clientFirstName`, `clientSurname`, `regNo`, `vehicleType`, `dailyRate`, `fuelType`, `Taken`, `Returned`) VALUES ('Zodwa', ' Zondi', 'WQA 9928 FS', 'SUV', 1350, 'Electric', '2024-04-24', '2024-04-26');
INSERT INTO `tblRentals` (`clientFirstName`, `clientSurname`, `regNo`, `vehicleType`, `dailyRate`, `fuelType`, `Taken`, `Returned`) VALUES ('Andile', ' Hlongwane', 'XRE 0077 ZN', NULL, 450, 'Petrol', '2024-05-20', '2024-05-25');
INSERT INTO `tblRentals` (`clientFirstName`, `clientSurname`, `regNo`, `vehicleType`, `dailyRate`, `fuelType`, `Taken`, `Returned`) VALUES ('Nomvula', ' Khumalo', 'XDT 5924 ZN', 'Sedan', 400, 'Electric', '2024-05-21', '2024-05-23');
INSERT INTO `tblRentals` (`clientFirstName`, `clientSurname`, `regNo`, `vehicleType`, `dailyRate`, `fuelType`, `Taken`, `Returned`) VALUES ('John', ' Doe', 'RHL 1444 WC', 'Sedan', 600, 'Hybrid', '2024-05-21', '2024-05-23');
INSERT INTO `tblRentals` (`clientFirstName`, `clientSurname`, `regNo`, `vehicleType`, `dailyRate`, `fuelType`, `Taken`, `Returned`) VALUES ('Rebecca', ' Mahlangu', 'RDK 5548 ZN', NULL, 1300, 'Petrol', '2024-05-22', '2024-05-27');
INSERT INTO `tblRentals` (`clientFirstName`, `clientSurname`, `regNo`, `vehicleType`, `dailyRate`, `fuelType`, `Taken`, `Returned`) VALUES ('Mandla', ' Khumalo', 'YHJ 8824 MP', 'Sedan', 500, 'Electric', '2024-05-31', '2024-06-05');
INSERT INTO `tblRentals` (`clientFirstName`, `clientSurname`, `regNo`, `vehicleType`, `dailyRate`, `fuelType`, `Taken`, `Returned`) VALUES ('Jabu', ' Dlamini', 'PLT 7712 GP', 'Convertible', 1600, 'Electric', '2024-06-04', '2024-06-11');
INSERT INTO `tblRentals` (`clientFirstName`, `clientSurname`, `regNo`, `vehicleType`, `dailyRate`, `fuelType`, `Taken`, `Returned`) VALUES ('Nomsa', ' Dlamini', 'FWE 2388 NC', 'SUV', 1300, 'Electric', '2024-06-05', '2024-06-09');
INSERT INTO `tblRentals` (`clientFirstName`, `clientSurname`, `regNo`, `vehicleType`, `dailyRate`, `fuelType`, `Taken`, `Returned`) VALUES ('Sibongile', ' Mkhize', 'XQW 4697 MP', 'Minivan', 850, 'Petrol', '2024-06-06', '2024-06-11');
INSERT INTO `tblRentals` (`clientFirstName`, `clientSurname`, `regNo`, `vehicleType`, `dailyRate`, `fuelType`, `Taken`, `Returned`) VALUES ('Nokuthula', ' Mlambo', 'PLP 8871 MP', 'SUV', 1100, 'Electric', '2024-06-14', '2024-06-21');
INSERT INTO `tblRentals` (`clientFirstName`, `clientSurname`, `regNo`, `vehicleType`, `dailyRate`, `fuelType`, `Taken`, `Returned`) VALUES ('Emily', ' Brown', 'EAQ 0247 GP', 'SUV', 1200, 'Electric', '2024-06-14', '2024-06-19');
INSERT INTO `tblRentals` (`clientFirstName`, `clientSurname`, `regNo`, `vehicleType`, `dailyRate`, `fuelType`, `Taken`, `Returned`) VALUES ('John', ' Doe', 'RHL 1444 WC', 'Sedan', 600, 'Hybrid', '2024-06-21', '2024-06-24');
INSERT INTO `tblRentals` (`clientFirstName`, `clientSurname`, `regNo`, `vehicleType`, `dailyRate`, `fuelType`, `Taken`, `Returned`) VALUES ('Lebo', ' Mokoena', 'ZTQ 9871 GP', 'Convertible', 1500, 'Electric', '2024-06-24', '2024-06-25');
INSERT INTO `tblRentals` (`clientFirstName`, `clientSurname`, `regNo`, `vehicleType`, `dailyRate`, `fuelType`, `Taken`, `Returned`) VALUES ('Michael', ' Green', 'HHW 4678 GP', 'Sedan', 950, 'Petrol', '2024-06-26', '2024-07-03');
INSERT INTO `tblRentals` (`clientFirstName`, `clientSurname`, `regNo`, `vehicleType`, `dailyRate`, `fuelType`, `Taken`, `Returned`) VALUES ('Nonhlanhla', ' Mbatha', 'XLO 8876 MP', NULL, 500, 'Electric', '2024-07-02', '2024-07-03');
INSERT INTO `tblRentals` (`clientFirstName`, `clientSurname`, `regNo`, `vehicleType`, `dailyRate`, `fuelType`, `Taken`, `Returned`) VALUES ('Sindi', ' Ndlovu', 'PQS 9981 ZN', 'Hatchback', 500, 'Petrol', '2024-07-04', '2024-07-07');
INSERT INTO `tblRentals` (`clientFirstName`, `clientSurname`, `regNo`, `vehicleType`, `dailyRate`, `fuelType`, `Taken`, `Returned`) VALUES ('Mandla', ' Khumalo', 'YHJ 8824 MP', 'Sedan', 500, 'Electric', '2024-07-11', '2024-07-16');
INSERT INTO `tblRentals` (`clientFirstName`, `clientSurname`, `regNo`, `vehicleType`, `dailyRate`, `fuelType`, `Taken`, `Returned`) VALUES ('Sipho', ' Ndlovu', 'STP 3346 NC', 'Sedan', 400, 'Electric', '2024-07-12', '2024-07-17');
INSERT INTO `tblRentals` (`clientFirstName`, `clientSurname`, `regNo`, `vehicleType`, `dailyRate`, `fuelType`, `Taken`, `Returned`) VALUES ('Amahle', ' Tshabalala', 'SWQ 7818 GP', 'Minivan', 800, 'Petrol', '2024-07-15', '2024-07-20');
INSERT INTO `tblRentals` (`clientFirstName`, `clientSurname`, `regNo`, `vehicleType`, `dailyRate`, `fuelType`, `Taken`, `Returned`) VALUES ('Edward', ' Ngwenya', 'ERT 9238 GP', 'Hatchback', 550, 'Electric', '2024-07-16', '2024-07-18');
INSERT INTO `tblRentals` (`clientFirstName`, `clientSurname`, `regNo`, `vehicleType`, `dailyRate`, `fuelType`, `Taken`, `Returned`) VALUES ('Fikile', ' Zuma', 'RTY 7812 NC', 'SUV', 1100, 'Petrol', '2024-07-16', '2024-07-23');
INSERT INTO `tblRentals` (`clientFirstName`, `clientSurname`, `regNo`, `vehicleType`, `dailyRate`, `fuelType`, `Taken`, `Returned`) VALUES ('Zinhle', ' Nkosi', 'YRW 9981 MP', 'SUV', 1300, 'Petrol', '2024-07-16', '2024-07-23');
INSERT INTO `tblRentals` (`clientFirstName`, `clientSurname`, `regNo`, `vehicleType`, `dailyRate`, `fuelType`, `Taken`, `Returned`) VALUES ('Ntombi', ' Nkosi', 'FSQ 9918 MP', 'Sedan', 650, 'Electric', '2024-07-25', '2024-07-26');
INSERT INTO `tblRentals` (`clientFirstName`, `clientSurname`, `regNo`, `vehicleType`, `dailyRate`, `fuelType`, `Taken`, `Returned`) VALUES ('Siphesihle', ' Maduna', 'QUZ 4499 ZN', 'Sedan', 700, 'Petrol', '2024-08-03', '2024-08-08');
INSERT INTO `tblRentals` (`clientFirstName`, `clientSurname`, `regNo`, `vehicleType`, `dailyRate`, `fuelType`, `Taken`, `Returned`) VALUES ('Emily', ' Brown', 'EAQ 0247 GP', 'SUV', 1200, 'Electric', '2024-08-08', '2024-08-10');
INSERT INTO `tblRentals` (`clientFirstName`, `clientSurname`, `regNo`, `vehicleType`, `dailyRate`, `fuelType`, `Taken`, `Returned`) VALUES ('Ntombi', ' Nkosi', 'FSQ 9918 MP', 'Sedan', 650, 'Electric', '2024-08-18', '2024-08-23');
INSERT INTO `tblRentals` (`clientFirstName`, `clientSurname`, `regNo`, `vehicleType`, `dailyRate`, `fuelType`, `Taken`, `Returned`) VALUES ('Nomvula', ' Khumalo', 'XDT 5924 ZN', 'Sedan', 400, 'Electric', '2024-08-20', '2024-08-22');
INSERT INTO `tblRentals` (`clientFirstName`, `clientSurname`, `regNo`, `vehicleType`, `dailyRate`, `fuelType`, `Taken`, `Returned`) VALUES ('Nomvula', ' Khumalo', 'XDT 5924 ZN', 'Sedan', 400, 'Electric', '2024-08-21', '2024-08-28');
INSERT INTO `tblRentals` (`clientFirstName`, `clientSurname`, `regNo`, `vehicleType`, `dailyRate`, `fuelType`, `Taken`, `Returned`) VALUES ('Zanele', ' Mthembu', 'KKP 7743 WC', 'Hatchback', 550, 'Petrol', '2024-08-25', '2024-08-29');
INSERT INTO `tblRentals` (`clientFirstName`, `clientSurname`, `regNo`, `vehicleType`, `dailyRate`, `fuelType`, `Taken`, `Returned`) VALUES ('Michael', ' Green', 'HHW 4678 GP', 'Sedan', 950, 'Petrol', '2024-09-06', '2024-09-08');
INSERT INTO `tblRentals` (`clientFirstName`, `clientSurname`, `regNo`, `vehicleType`, `dailyRate`, `fuelType`, `Taken`, `Returned`) VALUES ('Mandla', ' Khumalo', 'YHJ 8824 MP', 'Sedan', 500, 'Electric', '2024-09-15', '2024-09-22');
INSERT INTO `tblRentals` (`clientFirstName`, `clientSurname`, `regNo`, `vehicleType`, `dailyRate`, `fuelType`, `Taken`, `Returned`) VALUES ('Daniel', ' Smith', 'MRU 6619 FS', 'Sedan', 700, 'Electric', '2024-09-18', '2024-09-22');
INSERT INTO `tblRentals` (`clientFirstName`, `clientSurname`, `regNo`, `vehicleType`, `dailyRate`, `fuelType`, `Taken`, `Returned`) VALUES ('Amahle', ' Tshabalala', 'SWQ 7818 GP', 'Minivan', 800, 'Petrol', '2024-09-23', '2024-09-25');
INSERT INTO `tblRentals` (`clientFirstName`, `clientSurname`, `regNo`, `vehicleType`, `dailyRate`, `fuelType`, `Taken`, `Returned`) VALUES ('Thandeka', ' Zulu', 'YPB 9493 NC', 'SUV', 1000, 'Petrol', '2024-09-24', '2024-09-25');
INSERT INTO `tblRentals` (`clientFirstName`, `clientSurname`, `regNo`, `vehicleType`, `dailyRate`, `fuelType`, `Taken`, `Returned`) VALUES ('Cynthia', ' Sithole', 'WUV 1025 FS', 'Minivan', 1200, 'Hybrid', '2024-09-30', '2024-10-06');
INSERT INTO `tblRentals` (`clientFirstName`, `clientSurname`, `regNo`, `vehicleType`, `dailyRate`, `fuelType`, `Taken`, `Returned`) VALUES ('Lebo', ' Mokoena', 'ZTQ 9871 GP', 'Convertible', 1500, 'Electric', '2024-10-02', '2024-10-03');
# 64 records

