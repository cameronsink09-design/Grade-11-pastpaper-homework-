#
# DUMP FILE
#
# Database is ported from MS Access
#------------------------------------------------------------------
# Created using "MS Access to MySQL" form http://www.bullzip.com
# Program Version 5.4.274
#
# OPTIONS:
#   sourcefilename=T:\Data\Work\Grade 11 IT\2018\Nov Exams\Comrades.mdb
#   sourceusername=
#   sourcepassword=
#   sourcesystemdatabase=
#   destinationdatabase=Comrades
#   storageengine=InnoDB
#   dropdatabase=0
#   createtables=1
#   unicode=1
#   autocommit=1
#   transferdefaultvalues=1
#   transferindexes=1
#   transferautonumbers=1
#   transferrecords=1
#   columnlist=1
#   tableprefix=
#   negativeboolean=0
#   ignorelargeblobs=0
#   memotype=LONGTEXT
#   datetimetype=DATETIME
#

CREATE DATABASE IF NOT EXISTS `Comrades`;
USE `Comrades`;

#
# Table structure for table 'tblResults'
#

DROP TABLE IF EXISTS `tblResults`;

CREATE TABLE `tblResults` (
  `Year` INTEGER NULL, 
  `Up` TINYINT(1), 
  `Gender` VARCHAR(255), 
  `Time` TIME, 
  `Country` VARCHAR(255), 
  `Name` VARCHAR(255), 
  `Club` VARCHAR(255)
) ENGINE=innodb DEFAULT CHARSET=utf8;

SET autocommit=1;

#
# Dumping data for table 'tblResults'
#

INSERT INTO `tblResults` (`Year`, `Up`, `Gender`, `Time`, `Country`, `Name`, `Club`) VALUES (1990, 1, 'F', '07:02:00', 'South Africa', 'Naidene Harrison', 'Ladysmith AC');
INSERT INTO `tblResults` (`Year`, `Up`, `Gender`, `Time`, `Country`, `Name`, `Club`) VALUES (1990, 1, 'M', '05:40:25', 'South Africa', 'Bruce Fordyce', 'Rand AC');
INSERT INTO `tblResults` (`Year`, `Up`, `Gender`, `Time`, `Country`, `Name`, `Club`) VALUES (1991, 0, 'F', '06:08:19', 'South Africa', 'Frith van der Merwe', 'Benoni Northerns AC');
INSERT INTO `tblResults` (`Year`, `Up`, `Gender`, `Time`, `Country`, `Name`, `Club`) VALUES (1991, 0, 'M', '05:40:53', 'South Africa', 'Nick Bester', 'Unknown');
INSERT INTO `tblResults` (`Year`, `Up`, `Gender`, `Time`, `Country`, `Name`, `Club`) VALUES (1992, 1, 'F', '06:51:05', 'South Africa', 'Frances van Blerk', 'Unknown');
INSERT INTO `tblResults` (`Year`, `Up`, `Gender`, `Time`, `Country`, `Name`, `Club`) VALUES (1992, 1, 'M', '05:46:11', 'South Africa', 'Jetman Msutu', 'Unknown');
INSERT INTO `tblResults` (`Year`, `Up`, `Gender`, `Time`, `Country`, `Name`, `Club`) VALUES (1993, 0, 'F', '06:55:07', 'South Africa', 'Tilda Tearle', 'Savages AC');
INSERT INTO `tblResults` (`Year`, `Up`, `Gender`, `Time`, `Country`, `Name`, `Club`) VALUES (1993, 0, 'M', '05:39:41', 'Germany', 'Charly Doll', 'Germany');
INSERT INTO `tblResults` (`Year`, `Up`, `Gender`, `Time`, `Country`, `Name`, `Club`) VALUES (1994, 1, 'F', '06:41:23', 'Russia', 'Valentina Lyakhova', 'Comrades International');
INSERT INTO `tblResults` (`Year`, `Up`, `Gender`, `Time`, `Country`, `Name`, `Club`) VALUES (1994, 1, 'M', '05:38:39', 'United States', 'Alberto Salazar', 'USA');
INSERT INTO `tblResults` (`Year`, `Up`, `Gender`, `Time`, `Country`, `Name`, `Club`) VALUES (1995, 0, 'F', '06:22:57', 'Germany', 'Maria Bak', 'Germany');
INSERT INTO `tblResults` (`Year`, `Up`, `Gender`, `Time`, `Country`, `Name`, `Club`) VALUES (1995, 0, 'M', '05:34:02', 'South Africa', 'Shaun Meiklejohn', 'Maxed Elite KZN');
INSERT INTO `tblResults` (`Year`, `Up`, `Gender`, `Time`, `Country`, `Name`, `Club`) VALUES (1996, 1, 'F', '06:13:23', 'United States', 'Ann Trason', 'USA');
INSERT INTO `tblResults` (`Year`, `Up`, `Gender`, `Time`, `Country`, `Name`, `Club`) VALUES (1996, 1, 'M', '05:29:33', 'Russia', 'Dmitri Grishine', 'Rentmeester Fattis & Monis WP');
INSERT INTO `tblResults` (`Year`, `Up`, `Gender`, `Time`, `Country`, `Name`, `Club`) VALUES (1997, 0, 'F', '05:58:24', 'United States', 'Ann Trason', 'USA');
INSERT INTO `tblResults` (`Year`, `Up`, `Gender`, `Time`, `Country`, `Name`, `Club`) VALUES (1997, 0, 'M', '05:28:37', 'South Africa', 'Charl Mattheus', 'Rentmeester Fattis & Monis WP');
INSERT INTO `tblResults` (`Year`, `Up`, `Gender`, `Time`, `Country`, `Name`, `Club`) VALUES (1998, 1, 'F', '06:38:57', 'South Africa', 'Rae Bisschoff', 'Rocky Road Runners');
INSERT INTO `tblResults` (`Year`, `Up`, `Gender`, `Time`, `Country`, `Name`, `Club`) VALUES (1998, 1, 'M', '05:26:25', 'Russia', 'Dmitri Grishine', 'Rentmeester Fattis & Monis WP');
INSERT INTO `tblResults` (`Year`, `Up`, `Gender`, `Time`, `Country`, `Name`, `Club`) VALUES (1999, 0, 'F', '06:31:03', 'Germany', 'Birgit Lennartz', 'Germany');
INSERT INTO `tblResults` (`Year`, `Up`, `Gender`, `Time`, `Country`, `Name`, `Club`) VALUES (1999, 0, 'M', '05:30:10', 'Poland', 'Jaroslaw Janicki', 'Maxed Elite International');
INSERT INTO `tblResults` (`Year`, `Up`, `Gender`, `Time`, `Country`, `Name`, `Club`) VALUES (2000, 1, 'F', '06:15:35', 'Germany', 'Maria Bak', 'Germany');
INSERT INTO `tblResults` (`Year`, `Up`, `Gender`, `Time`, `Country`, `Name`, `Club`) VALUES (2000, 1, 'M', '05:25:33', 'Belarus', 'Vladimir Kotov', 'Maxed Elite International');
INSERT INTO `tblResults` (`Year`, `Up`, `Gender`, `Time`, `Country`, `Name`, `Club`) VALUES (2001, 0, 'F', '06:13:53', 'Russia', 'Elvira Kolpakova', 'Russia');
INSERT INTO `tblResults` (`Year`, `Up`, `Gender`, `Time`, `Country`, `Name`, `Club`) VALUES (2001, 0, 'M', '05:25:51', 'South Africa', 'Andrew Kelehe', 'Rentmeester Fattis & Monis GN');
INSERT INTO `tblResults` (`Year`, `Up`, `Gender`, `Time`, `Country`, `Name`, `Club`) VALUES (2002, 1, 'F', '06:14:21', 'Germany', 'Maria Bak', 'Germany');
INSERT INTO `tblResults` (`Year`, `Up`, `Gender`, `Time`, `Country`, `Name`, `Club`) VALUES (2002, 1, 'M', '05:30:59', 'Belarus', 'Vladimir Kotov', 'Maxed Elite International');
INSERT INTO `tblResults` (`Year`, `Up`, `Gender`, `Time`, `Country`, `Name`, `Club`) VALUES (2003, 0, 'F', '06:07:46', 'Russia', 'Elena Nurgalieva', 'Russia');
INSERT INTO `tblResults` (`Year`, `Up`, `Gender`, `Time`, `Country`, `Name`, `Club`) VALUES (2003, 0, 'M', '05:28:52', 'South Africa', 'Fusi Nhlapo', 'Liberty Nike AC CG');
INSERT INTO `tblResults` (`Year`, `Up`, `Gender`, `Time`, `Country`, `Name`, `Club`) VALUES (2004, 1, 'F', '06:11:15', 'Russia', 'Elena Nurgalieva', 'Premier AC');
INSERT INTO `tblResults` (`Year`, `Up`, `Gender`, `Time`, `Country`, `Name`, `Club`) VALUES (2004, 1, 'M', '05:31:22', 'Belarus', 'Vladimir Kotov', 'Maxed Elite PE');
INSERT INTO `tblResults` (`Year`, `Up`, `Gender`, `Time`, `Country`, `Name`, `Club`) VALUES (2005, 0, 'F', '05:58:50', 'Russia', 'Tatyana Zhirkova', 'Russia');
INSERT INTO `tblResults` (`Year`, `Up`, `Gender`, `Time`, `Country`, `Name`, `Club`) VALUES (2005, 0, 'M', '05:27:10', 'South Africa', 'Sipho Ngomane', 'Harmony AC MPL');
INSERT INTO `tblResults` (`Year`, `Up`, `Gender`, `Time`, `Country`, `Name`, `Club`) VALUES (2006, 1, 'F', '06:09:24', 'Russia', 'Elena Nurgalieva', 'Russia');
INSERT INTO `tblResults` (`Year`, `Up`, `Gender`, `Time`, `Country`, `Name`, `Club`) VALUES (2006, 1, 'M', '05:35:19', 'Russia', 'Oleg Kharitonov', 'Harmony International');
INSERT INTO `tblResults` (`Year`, `Up`, `Gender`, `Time`, `Country`, `Name`, `Club`) VALUES (2007, 0, 'F', '06:10:11', 'Russia', 'Olesya Nurgalieva', 'Harmony International');
INSERT INTO `tblResults` (`Year`, `Up`, `Gender`, `Time`, `Country`, `Name`, `Club`) VALUES (2007, 0, 'M', '05:20:49', 'Russia', 'Leonid Shvetsov', 'Harmony International');
INSERT INTO `tblResults` (`Year`, `Up`, `Gender`, `Time`, `Country`, `Name`, `Club`) VALUES (2008, 1, 'F', '06:14:38', 'Russia', 'Elena Nurgalieva', 'Maxed Elite International');
INSERT INTO `tblResults` (`Year`, `Up`, `Gender`, `Time`, `Country`, `Name`, `Club`) VALUES (2008, 1, 'M', '05:24:49', 'Russia', 'Leonid Shvetsov', 'Harmony International');
INSERT INTO `tblResults` (`Year`, `Up`, `Gender`, `Time`, `Country`, `Name`, `Club`) VALUES (2009, 0, 'F', '06:12:08', 'Russia', 'Olesya Nurgalieva', 'Maxed Elite International');
INSERT INTO `tblResults` (`Year`, `Up`, `Gender`, `Time`, `Country`, `Name`, `Club`) VALUES (2009, 0, 'M', '05:23:27', 'Zimbabwe', 'Stephen Muzhingi', 'Formula 1 Bluff Meats AC');
INSERT INTO `tblResults` (`Year`, `Up`, `Gender`, `Time`, `Country`, `Name`, `Club`) VALUES (2010, 0, 'F', '06:13:03', 'Russia', 'Elena Nurgalieva', 'Maxed Elite International');
INSERT INTO `tblResults` (`Year`, `Up`, `Gender`, `Time`, `Country`, `Name`, `Club`) VALUES (2010, 0, 'M', '05:29:01', 'Zimbabwe', 'Stephen Muzhingi', 'Formula 1 Bluff Meats AC');
INSERT INTO `tblResults` (`Year`, `Up`, `Gender`, `Time`, `Country`, `Name`, `Club`) VALUES (2011, 1, 'F', '06:24:11', 'Russia', 'Elena Nurgalieva', 'Maxed Elite International');
INSERT INTO `tblResults` (`Year`, `Up`, `Gender`, `Time`, `Country`, `Name`, `Club`) VALUES (2011, 1, 'M', '05:32:45', 'Zimbabwe', 'Stephen Muzhingi', 'Formula 1 Bluff Meats AC');
INSERT INTO `tblResults` (`Year`, `Up`, `Gender`, `Time`, `Country`, `Name`, `Club`) VALUES (2012, 0, 'F', '06:07:12', 'Russia', 'Elena Nurgalieva', 'Maxed Elite International');
INSERT INTO `tblResults` (`Year`, `Up`, `Gender`, `Time`, `Country`, `Name`, `Club`) VALUES (2012, 0, 'M', '05:31:03', 'South Africa', 'Ludwick Mamabolo', 'Maxed Elite KZN');
INSERT INTO `tblResults` (`Year`, `Up`, `Gender`, `Time`, `Country`, `Name`, `Club`) VALUES (2013, 1, 'F', '06:27:09', 'Russia', 'Elena Nurgalieva', 'Maxed Elite International');
INSERT INTO `tblResults` (`Year`, `Up`, `Gender`, `Time`, `Country`, `Name`, `Club`) VALUES (2013, 1, 'M', '05:32:09', 'South Africa', 'Claude Moshiywa', 'Nedbank RC GN');
INSERT INTO `tblResults` (`Year`, `Up`, `Gender`, `Time`, `Country`, `Name`, `Club`) VALUES (2014, 0, 'F', '06:18:12', 'United Kingdom', 'Eleanor Greenwood', 'Nedbank International');
INSERT INTO `tblResults` (`Year`, `Up`, `Gender`, `Time`, `Country`, `Name`, `Club`) VALUES (2014, 0, 'M', '05:28:29', 'South Africa', 'Bongmusa Mthembu', 'Nedbank RC KZN');
INSERT INTO `tblResults` (`Year`, `Up`, `Gender`, `Time`, `Country`, `Name`, `Club`) VALUES (2015, 1, 'F', '06:12:22', 'South Africa', 'Caroline W�stmann', 'Nedbank RC');
INSERT INTO `tblResults` (`Year`, `Up`, `Gender`, `Time`, `Country`, `Name`, `Club`) VALUES (2015, 1, 'M', '05:38:36', 'South Africa', 'Gift Kelehe', 'Samancor Chrome MC');
INSERT INTO `tblResults` (`Year`, `Up`, `Gender`, `Time`, `Country`, `Name`, `Club`) VALUES (2016, 0, 'F', '06:25:55', 'South Africa', 'Charne Bosman', 'Nedbank RC CG');
INSERT INTO `tblResults` (`Year`, `Up`, `Gender`, `Time`, `Country`, `Name`, `Club`) VALUES (2016, 0, 'M', '05:18:19', 'South Africa', 'David Gatebe', 'TomTom AC');
INSERT INTO `tblResults` (`Year`, `Up`, `Gender`, `Time`, `Country`, `Name`, `Club`) VALUES (2017, 1, 'F', '06:27:35', 'United States', 'Camille Herron', 'Nedbank RC International');
INSERT INTO `tblResults` (`Year`, `Up`, `Gender`, `Time`, `Country`, `Name`, `Club`) VALUES (2017, 1, 'M', '05:35:34', 'South Africa', 'Bongmusa Mthembu', 'Arthur Ford AC');
INSERT INTO `tblResults` (`Year`, `Up`, `Gender`, `Time`, `Country`, `Name`, `Club`) VALUES (2018, 0, 'F', '06:10:03', 'South Africa', 'Ann Ashworth', 'Massmart AC CG');
INSERT INTO `tblResults` (`Year`, `Up`, `Gender`, `Time`, `Country`, `Name`, `Club`) VALUES (2018, 0, 'M', '05:26:34', 'South Africa', 'Bongmusa Mthembu', 'Arthur Ford AC');
# 58 records