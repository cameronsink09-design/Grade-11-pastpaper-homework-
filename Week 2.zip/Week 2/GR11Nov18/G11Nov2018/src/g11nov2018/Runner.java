/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package g11nov2018;

import java.util.Scanner;

/**
 *
 * @author delia
 */
public class Runner
{

    private String time;
    private String name;
    private String club;

    public Runner(String time, String name, String club)
    {
        this.time = time;
        this.name = name;
        this.club = club;
    }

    public String getClub()
    {
        return club;
    }

    public int getTimeInMins()
    {
        Scanner sc = new Scanner(time).useDelimiter(":");
        int t = 0;
        int h = sc.nextInt();
        int m = sc.nextInt();
        int s = sc.nextInt();
        t = h * 60 + m;
        if (s > 30)
        {
            t++;
        }
        return t;

    }

    @Override
    public String toString()
    {
        return name + "\t" + club + "\t" + time;
    }

}
