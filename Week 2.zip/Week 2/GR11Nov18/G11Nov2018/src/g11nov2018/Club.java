/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package g11nov2018;

/**
 *
 * @author delia
 */
public class Club
{
    private String name;
    private double ave;

    public Club(String name, double a)
    {
        this.name = name;
        this.ave = a;
    }
   

    public double getAve()
    {
        return ave;
    }

    @Override
    public String toString()
    {
        return "Club: " + name + ", total time = " + ave;
    }
    
    
}
