/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package g11nov2018;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.Scanner;

/**
 *
 * @author delia
 */
public class RunnerArray
{

    private Runner[] rArr = new Runner[100];
    private ClubArray ca = new ClubArray();
    private int rSize = 0;

    public RunnerArray()
    {

        try
        {
            Scanner scFile = new Scanner(new FileReader("data.txt"));
            String n, t, c;

            while (scFile.hasNextLine())
            {
                String line = scFile.nextLine();

                Scanner scLine = new Scanner(line).useDelimiter(",");

                t = scLine.next();
                n = scLine.next();
                c = scLine.next();

                rArr[rSize] = new Runner(t, n, c);
                rSize++;
            }
            scFile.close();
        } catch (FileNotFoundException ex)
        {
            System.out.println("File not found");
        }

    }

    public ClubArray calcAveTimes()
    {

        String temp = "#";
        double ave = 0;
        for (int i = 0; i < rSize - 1; i++)
        {
            double total = 0;
            int count = 0;
            for (int j = i + 1; j < rSize; j++)
            {
                if (rArr[i].getClub().equals(rArr[j].getClub()) && (!temp.contains("#" + rArr[i].getClub() + "#")))
                {
                    total = total + rArr[j].getTimeInMins();
                    System.out.println(rArr[j].getClub() + " " + total); 
                    count++;
                }

            }
            
            if (!temp.contains("#" + rArr[i].getClub() + "#"))
            {                
                temp += rArr[i].getClub() + "#";
                ave = (double) total / count; 
                ca.addClub(ave, rArr[i].getClub());
                System.out.println("average " + ave);
            }
        }
        return ca;
    }

   
    public String toString()
    {
        String rString = "";
        for (int i = 0; i < rSize; i++)
        {
            rString += rArr[i].toString() + "\n";
        }

        return rString;
    }

}
