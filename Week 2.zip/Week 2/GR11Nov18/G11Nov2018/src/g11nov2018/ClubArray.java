/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package g11nov2018;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.Scanner;

/**
 *
 * @author delia
 */
public class ClubArray
{

    private Club[] cArr = new Club[100];
    private int cSize = 0;

    public ClubArray()
    {

    }

    public void addClub(double a, String n)
    {
        cArr[cSize] = new Club(n, a);
        cSize++;
    }


    public String toString()
    {
        String rString = "";
        for (int i = 0; i < cSize; i++)
        {
            rString += cArr[i].toString() + "\n";
        }

        return rString;
    }

    public void sort()
    {

        for (int i = 0; i < cSize - 1; i++)
        {
            for (int j = i + 1; j < cSize; j++)
            {
                if (cArr[i].getAve() < cArr[j].getAve())
                {
                    Club temp = cArr[i];
                    cArr[i] = cArr[j];
                    cArr[j] = temp;
                }
            }

        }

    }
}
