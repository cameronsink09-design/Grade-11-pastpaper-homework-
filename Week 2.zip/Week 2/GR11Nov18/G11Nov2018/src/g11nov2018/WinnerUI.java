/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package g11nov2018;

/**
 *
 * @author delia
 */
public class WinnerUI
{

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args)
    {
        RunnerArray ra = new RunnerArray();
        System.out.println("Runners\n" +ra);
        ClubArray ca = ra.calcAveTimes();
        System.out.println("\n\nClubs and Ave Times\n" + ca.toString());
        ca.sort();
        System.out.println("\n\nClubs in Descending Order\n" + ca.toString());
    }
    
}
